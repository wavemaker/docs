-- MySQL dump 10.13  Distrib 5.5.38, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: AssetsDB
-- ------------------------------------------------------
-- Server version	5.5.38-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `AssetsDB`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `AssetsDB` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `AssetsDB`;

--
-- Table structure for table `DEPARTMENT`
--

DROP TABLE IF EXISTS `DEPARTMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DEPARTMENT` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DEPARTMENT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PASSWORD` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USERNAME` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_ROLE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEPARTMENT`
--

LOCK TABLES `DEPARTMENT` WRITE;
/*!40000 ALTER TABLE `DEPARTMENT` DISABLE KEYS */;
INSERT INTO `DEPARTMENT` VALUES (1,'IT','itadmin','itadmin','admin'),(2,'Sales','sales','sales','user'),(3,'Finance','finance','finance','user'),(4,'Marketing','marketing','marketing','user');
/*!40000 ALTER TABLE `DEPARTMENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEVICE_INVENTORY`
--

DROP TABLE IF EXISTS `DEVICE_INVENTORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DEVICE_INVENTORY` (
  `DEVICE ID` int(11) NOT NULL AUTO_INCREMENT,
  `COST` int(11) DEFAULT NULL,
  `DATE OF PURCHASE` date DEFAULT NULL,
  `DISPLAY SIZE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGEURL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MEMORY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODEL ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MODEL NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PROCESSOR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `QTY` int(11) DEFAULT NULL,
  `STORAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WARRANT EXPIRY DATE` date DEFAULT NULL,
  `YEAR OF MANUFACTURE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CATALOG_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`DEVICE ID`),
  UNIQUE KEY `UK_q9cfa2mynxhvqewf90xsyyg9h` (`MODEL ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEVICE_INVENTORY`
--

LOCK TABLES `DEVICE_INVENTORY` WRITE;
/*!40000 ALTER TABLE `DEVICE_INVENTORY` DISABLE KEYS */;
INSERT INTO `DEVICE_INVENTORY` VALUES (1,685,NULL,'14\"','http://www.wavemaker.com/learn/wp-content/uploads/white-01.jpg','4 GB',NULL,'Intel Windows','Intel Core i5-3337U',176,'500 GB','2016-06-02','2015','Laptop'),(2,1415,NULL,'21.5\"','http://www.wavemaker.com/learn/wp-content/uploads/white-05.jpg','8 GB',NULL,'Mac Book Pro','1.6GHz dual-core Intel Core i5',NULL,'1 TB','2016-05-27','2015','Desktop'),(3,315,NULL,'19.5\"','http://www.wavemaker.com/learn/wp-content/uploads/white-06.jpg','2 GB',NULL,'Desktop Black','Intel Celeron',188,'500 GB HDD','2016-05-30','2015','Desktop'),(4,1900,NULL,'21.5\"','http://www.wavemaker.com/learn/wp-content/uploads/white-04.jpg','3 GB',NULL,'Desktop - large','i5 3.4 GHZ',186,'1 TB','2017-06-06','2017','Desktop'),(5,735,'2015-07-15','5\"','http://www.wavemaker.com/learn/wp-content/uploads/white-13.jpg','2 GB',NULL,'Android','A6',184,'16 GB','2016-07-05','2015','SmartPhone'),(8,1185,'2016-03-26','27\"','http://www.wavemaker.com/learn/wp-content/uploads/white-03.jpg','8 GB',NULL,'Desktop - Retina','Intel i7 dual core',187,'1TB','2017-03-26','2015','Desktop'),(9,1185,'2016-03-26','27\"','http://www.wavemaker.com/learn/wp-content/uploads/white-03.jpg','8 GB',NULL,'Desktop - Retina','Intel i7 dual core',197,'1TB','2017-03-26','2015','Desktop'),(10,540,'2016-02-10','21\"','http://www.wavemaker.com/learn/wp-content/uploads/white-02.jpg','6 GB',NULL,'Flat 17 inch','intel i5',193,'500 GB HDD','2017-02-10','2015','Desktop'),(11,540,'2016-02-10','21\"','http://www.wavemaker.com/learn/wp-content/uploads/white-02.jpg','6 GB',NULL,'Flat 17 inch','intel i5',135,'500 GB HDD','2017-02-10','2015','Desktop'),(12,765,'2016-01-29','15.6\"','http://www.wavemaker.com/learn/wp-content/uploads/white-08.jpg','8 GB',NULL,'Intel Windows','Intel i7 dual core',181,'1 TB','2017-01-29','2015','Laptop'),(13,399,'2016-04-12','5.2\"','http://www.wavemaker.com/learn/wp-content/uploads/white-12.jpg','2 GB',NULL,'IPhone Look Alike','1.8 GHz + Qualcomm Snapdragon',169,'32 GB','2017-04-12','2015','SmartPhone'),(15,349,'2016-03-04','7\"','http://www.wavemaker.com/learn/wp-content/uploads/white-10.jpg','2 GB',NULL,'Android Samsung look alike','AMD',175,'32 GB','2017-03-05','2016','SmartPhone');
/*!40000 ALTER TABLE `DEVICE_INVENTORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REQUESTED`
--

DROP TABLE IF EXISTS `REQUESTED`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REQUESTED` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ASSIGNED` bit(1) DEFAULT b'0',
  `ASSIGNED_DATE` date DEFAULT NULL,
  `REQUESTED_DATE` date DEFAULT NULL,
  `REQUESTED_QTY` int(11) DEFAULT NULL,
  `DEVICE ID` int(11) DEFAULT NULL,
  `DEPT_ID` int(11) DEFAULT NULL,
  `ASSIGNED_QTY` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_re8x4k2m37jq8lkupp453pavv` (`DEVICE ID`),
  KEY `FK_REQUESTED_TO_DEPARTMEDivHh` (`DEPT_ID`),
  CONSTRAINT `FK_re8x4k2m37jq8lkupp453pavv` FOREIGN KEY (`DEVICE ID`) REFERENCES `DEVICE_INVENTORY` (`DEVICE ID`),
  CONSTRAINT `FK_REQUESTED_TO_DEPARTMEDivHh` FOREIGN KEY (`DEPT_ID`) REFERENCES `DEPARTMENT` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REQUESTED`
--

LOCK TABLES `REQUESTED` WRITE;
/*!40000 ALTER TABLE `REQUESTED` DISABLE KEYS */;
INSERT INTO `REQUESTED` VALUES (13,'','2016-12-25','2016-12-24',4,11,1,4),(14,'','2016-12-25','2016-12-24',3,11,1,3),(15,'','2016-12-25','2016-12-24',4,15,1,6),(16,'','2016-12-25','2016-12-24',5,13,1,5),(18,'','2016-12-25','2016-12-24',5,11,1,5),(19,'','2016-12-25','2016-12-24',7,1,1,4),(20,'','2016-12-25','2016-12-24',4,8,1,4),(21,'','2016-12-25','2016-12-24',2,4,1,2),(22,'',NULL,'2016-12-24',5,2,2,NULL),(23,'','2016-12-25','2016-12-24',6,5,1,6),(24,'','2016-12-26','2016-12-24',4,3,1,4),(25,'','2016-12-26','2016-12-24',6,12,1,6),(26,'','2016-12-26','2016-12-24',5,13,1,5),(27,'\0','2016-12-26','2016-12-24',8,3,1,8),(28,'','2017-01-12','2016-12-24',4,1,2,NULL),(29,'','2017-02-22','2016-12-24',6,15,1,6),(30,'\0',NULL,'2016-12-24',5,9,4,NULL),(31,'\0',NULL,'2016-12-24',4,11,4,NULL),(32,'\0',NULL,'2016-12-24',3,13,4,NULL),(33,'\0',NULL,'2016-12-24',6,10,4,NULL),(34,'\0',NULL,'2016-12-24',5,5,4,NULL),(35,'\0',NULL,'2016-12-24',5,10,4,NULL),(36,'\0',NULL,'2016-12-24',7,12,4,NULL),(37,'\0',NULL,'2016-12-24',3,12,1,NULL),(38,'\0',NULL,'2016-12-24',5,13,1,NULL),(39,'\0',NULL,'2016-12-25',1,2,2,NULL),(40,'\0',NULL,'2016-12-25',1,3,2,NULL),(41,'\0',NULL,'2016-12-25',1,8,2,NULL),(42,'\0',NULL,'2016-12-25',4,13,1,NULL),(43,'\0',NULL,'2016-12-25',3,12,1,NULL),(44,'\0',NULL,'2016-12-26',3,2,4,NULL),(45,'\0',NULL,'2016-12-26',5,3,4,NULL),(46,'\0',NULL,'2016-12-26',6,12,4,NULL),(47,'\0',NULL,'2017-01-12',1,2,2,NULL),(48,'\0',NULL,'2017-01-12',1,3,2,NULL);
/*!40000 ALTER TABLE `REQUESTED` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'AssetsDB'
--
/*!50003 DROP PROCEDURE IF EXISTS `dev_in_out` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `dev_in_out`(IN in_devid varchar(255), OUT total integer)
BEGIN SELECT COUNT(deviceId)
into total
FROM DEVICE_INVENTORY
WHERE CATALOG_NAME = in_devid;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-24  5:00:24
