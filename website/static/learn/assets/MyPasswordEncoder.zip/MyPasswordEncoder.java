package com.wavemaker.runtime.security.provider.database.users;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCrypt;

/**
 * Created by arjuns on 17/1/17.
 */
public class BCryptPasswordEncoder implements PasswordEncoder {

    private static final Logger logger = LoggerFactory.getLogger(BCryptPasswordEncoder.class);

    @Override
    public String encodePassword(final String rawPass, final Object salt) {
        return null;
    }

    @Override
    public boolean isPasswordValid(final String encodedPassword, final String rawPassword, final Object salt) {
        if (encodedPassword == null || encodedPassword.length() == 0) {
            logger.warn("Empty encoded password");
            return false;
        }
        return BCrypt.checkpw(rawPassword, encodedPassword);
    }
}
